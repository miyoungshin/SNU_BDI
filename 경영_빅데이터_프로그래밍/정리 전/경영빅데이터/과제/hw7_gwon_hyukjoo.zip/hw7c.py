# Assignment Number..: 과제 7 / C 타입
# Author.............: 권 혁 주
# File name..........: hw7c.py
# Written Date.......: 20170721
# Program Description: 콤마로 분리된 데이터 셋을 불러와 파싱하는 법/ 데이터 전처리/ 범주형 데이터 인코딩 방법을 익힌다.

import unicodecsv #unicodecsv 모듈을 불러옴

car = open('car.csv','rb') # 저장한 car.csv 파일을 오픈함수를 통해 읽음
reader = unicodecsv.DictReader(car) # DictReader()함수를 통해 데이터를 불러와 reader에 저장


result = [] # 결과 값을 저장하기 위한 list 형식의 변수 생성
for i in reader : # 데이터를 list에 저장하기 위해 for문을 활용
	result.append(i)
print(result[0]) # 리스트의 첫번째 요소를 출력함

def parser_doors(n) : # doors 변수를 반환하기 위한 함수를 정의
	for i in n : # 각 줄의 doors 변수의 인자 값을 변환하기 위해 for문 활용
		if i['doors'] == '2': # 각 딕셔너리의 doors값이 '2'이면 2로 변환
			i['doors'] = 2 
		elif i['doors'] == '3': # 각 딕셔너리의 doors값이 '3'이면 3로 변환
			i['doors'] = 3
		elif i['doors'] == '4': # 각 딕셔너리의 doors값이 '4'이면 4로 변환
			i['doors'] = 4
		elif i['doors'] == '5more' : # 각 딕셔너리의 doors값이 '5more'이면 5로 변환
			i['doors'] = 5
parser_doors(result) # 정의된 함수를 result에 적용

def parser_class(n) : # class 변수를 반환하기 위한 함수를 정의
	for i in n : # 각 줄의 class 변수의 인자 값을 변환하기 위해 for문 활용
		if i['class'] == 'unacc': # 각 딕셔너리의 class값이 'unacc'이면 0로 변환
			i['class'] = 0
		elif i['class'] == 'acc': # 각 딕셔너리의 class값이 'acc'이면 1로 변환 
			i['class'] = 1
		elif i['class'] == 'good': # 각 딕셔너리의 class값이 'good'이면 2로 변환
			i['class'] = 2
		elif i['class'] == 'vgood' : # 각 딕셔너리의 class값이 'vgood'이면 3로 변환
			i['class'] = 3
parser_class(result) # 정의된 함수를 result에 적용

print(result[0]) # 변환된 리스트의 첫번째 줄의 값을 출력

