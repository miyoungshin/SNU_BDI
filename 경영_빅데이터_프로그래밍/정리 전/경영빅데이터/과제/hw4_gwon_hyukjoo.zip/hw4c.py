# Assignment Number..: 과제 4 / C 타입
# Author.............: 권 혁 주
# File name..........: hw4c.py
# Written Date.......: 20170704
# Program Description: 새로운 함수 정의하는 방법과 람다 함수를 익힌다.
def area_triangle(h,w): # 두개의 인수 h,w를 갖는 새로운 함수를 정의한다.
	return(h*w*0.5) # 삼각형의 면적공식을  연산을 만든다.
print(area_triangle(10,15)) # 함수를 불러와 10,15를 입력하고 출력한다.

def distance(a,b): # 새로운 함수를 정의한다.
	result = 0 # for문을 통한 결과를 받기 위한 인수값이 0인 result를 생성한다.
	for i in range(2) : # for문을 활용해 리스트 a,b의 i번째 값들의 차를 제곱한 값들을 result에 더해준다.  
		result += (((a[i]-b[i])**2))
	return((result)**0.5) # 결과값에 대해 0.5를 제곱해 최종 결과 값을 프린트 한다.
a = [1,2] # 인수값이 1과 2인 리스트를 생성한다.
b = [5,7] # 인수값이 5와 7인 리스트를 생성한다.
print(distance(a,b)) # 함수를 불러와 a와 b를 입력하고 출력한다.

def count(n): # 하나의 인수 n을 갖는 새로운 함수를 정의한다.
	if n > 0 : # 만약 n이 0보다 크면 
		print(n) # n을 출력한다.
		return count(n-1) # count(n-1)을 호출한다.
	elif n == 0: # 만약 n이 0이면
		return('zero!!') # zero!!를 받는다.
print(count(5)) #함수를 불러와 5를 입력해 결과값을 출력한다.

area_triangle_ld = lambda h, w : h*w*0.5 # 람다함수를 생성해 삼각형의 넓이를 구하는 연산을 만든다.
print(area_triangle_ld(10,15)) # 함수를 불러와 10,15를 입력하고 결과를 출력한다.