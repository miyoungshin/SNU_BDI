# Assignment Number..: 과제 5 / C 타입
# Author.............: 권 혁 주
# File name..........: hw5c.py
# Written Date.......: 20170709
# Program Description: 패키지와 모듈을 불러오는 법을 익힌다. csv파일을 불러와 읽는 방법을 익힌다.
import datetime # datetime 모듈을 불러옴 
now = datetime.datetime.now() # datetime함수를 이용해 현재 시간을 'now'변수에 저장 
print(now.strftime('%Y-%m-%d %H:%M:%S')) #strftime함수를 이용해 시간 표현 형식을 정의하고 결과를 print함수로 출력 

open('students.csv') # open함수를 이용해 'students.csv'파일을 불러옴
for i in open('students.csv') : # for문을 이용해 각 줄을 출력
	print(i)

import csv # csv 모듈을 불러옴 
file = open('students.csv') # open함수를 이용해 'students.csv' 파일을 읽어와 'file'변수에 저장 
file_csv = csv.reader(file) # read()함수를 이용해 file의 내용을 읽어오고 결과를 'file_csv'변수에 저장
for i in file_csv : # for문을 이용해 각 줄을 출력 
	print(i)