# Assignment Number..: 과제 2 / B 타입
# Author.............: 권 혁 주
# File name..........: hw2c.py
# Written Date.......: 20170627
# Program Description: 
letters = ('a', 'b', 'c', 'd', 'e') # 원소 a, b, c, d, e를 갖는 튜플 letters 생성
print(letters) # print를 사용해 출력
print(len(letters)) #len함수를 사용해 튜플 letters의 개수를 구해 print함수를 사용해 출력
for index, x in enumerate(letters) : 
	print(x.upper()) # 튜플 letters의 요소를 하나씩 받기 위해 for문과 enumerate를 활용한뒤 출력시 upper()를 이용해 대문자로 변환
plants = ['Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn'] # 원소 Mercury, Venus, Mars, Jupoter, Saturn를 갖는 리스트 plants 생성
print(plants) # print를 사용해 출력
plants_sub = plants[0:3] # 리스트 분할 연산자 '[]'을 화용해 plants_sub 리스트 생성
print(plants_sub) # print를 사용해 출력
grade = {'Kim':'A+', 'Lee':'C+', 'ParK':'B-','Han':'C-'} # grade 딕셔너리 생성 각각 원소에 키값을 할당
keys = grade.keys() # 모든 키를 원소르 가지는 셋 Key를 d.keys()를 사용해 생성 
print(keys)  # print를 사용해 출력
print(grade['Kim']) # 키값 Kim을 통해 성적을 출력
print(grade['Han']) # 키값 Han을 통해 성적을 출력