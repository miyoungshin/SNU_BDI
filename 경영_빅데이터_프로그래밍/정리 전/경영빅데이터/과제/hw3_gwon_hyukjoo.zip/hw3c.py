# Assignment Number..: 과제 3 / C 타입
# Author.............: 권 혁 주
# File name..........: hw3c.py
# Written Date.......: 20170702
# Program Description: String(str) 자료형 변수를 생성, 슬라이싱 방법, 중첩된 if-else문과 for/while문을 만든느 방법을 배운다
telephone = '0226159544' # telephone 변수 생성 후 String 자료형으로 저장
print(telephone) # print 활용 출력

area_code = telephone[0:2] # telephone 변수를 슬라이싱 해 area_code 변수를 생성
print(area_code) # print 활용 출력

number = telephone[2:] # telephone 변수를 슬라이싱 해 number 변수를 생성
print(number) # print 활용 출력

print(type(area_code)) # area_code 변수의 자료형을 출력
print(type(number)) # number 변수의 자료형을 출력

area_code_input = (input('What is the area code of your telephone number?')) # input함수를 활용해 지역번호를 물어보고 결과를 area_code_input변수에 저장
number_input = (input('What is your telephone number,without the area code?')) # input함수를 활용해 사용자의 전화번호를 물어보고 결과를 number_input변수에 저장
if area_code == area_code_input : # (바깥) area_code와 area_code_input 변수가 같으면
	if number == number_input : # number와 number_input 변수가 같다면
		print('Your telephone number is verified!!') # 번호가 확인되었다는 문구 출력
	else : # 같지 않다면
		print('Number is incorrect') # 번호가 불일치 하다는 문구 출력
else : #(바깥) 같지 않다면
	print('Area code is incorret') # 지역코드가 불일치 하다는 문구 출력

for i in range(0,10) : # 0~9까지의 범위를 가지고 있는 i에 대해
	print(i/10) # 10으로 나눈 결과값 출력

x = 0 # 변수를 지정
while x < 10 : # x < 10 인 경우 반복
	if x < 10 : # x가 10보다 작으면
		print(x/10) # 10으로 나눈 값을 출력
		x += 1 # x에 1을 더함
	else : # 그렇지 않으면(10보다 크거나 같으면)
		break # 중지


