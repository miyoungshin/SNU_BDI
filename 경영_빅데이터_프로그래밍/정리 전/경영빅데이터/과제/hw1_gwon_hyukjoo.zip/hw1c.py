# Assignment Number..: 과제 1 / C 타입
# Author.............: 권 혁 주
# File name..........: hw1c.py
# Written Date.......: 20170625
# Program Description: 
food = input('What is your favorite food?') # 사용자가 좋아하는 음식을 물어, food 변수에 할당
print(food) # 결과를 print변수를 활용해 출력

number = input('Pick any integer betwwen 1 and 10(1 ~ 10)') # 1 ~ 10 사이의 임의의 정수를 선택, number 변수에 할당
print('class',type(number)) # input을 통해 할당된 number 변수는 defult값이 str이기 때문에 바로 print함수와 type을 활용해 출력

number = int(number) # 자료형인 number변수를 integer타입으로 변경
print('class',type(number))  # number변수가 integer타입으로 변경되었기 때문에 str()을 통해 문자형으로 바꾸어 print함수와 type을 활용해 출력

if number % 2 == 1 : 
	print('You have Picked an odd integer!!') # integer타입이 홀수일 경우는 나누었을 때 나머지가 1인 경우이기 때문에 % 연산자를 활용
elif number % 2 == 0 :
	print('You have Picked an even integer!!') # integer타입이 짝수일 경우는 나누었을 때 나머지가 0인 경우이기 때문에 % 연산자를 활용